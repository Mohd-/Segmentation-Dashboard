# Dashboard SVG Icon Set

A complete redraw of every distinct icon and icon-like graphic visible in the two supplied dashboard screenshots. The package contains **32 standalone SVG files** with transparent backgrounds. Repeated screenshot uses—such as assignee, status, growth-chart, clipboard, and derrick symbols—share consistent geometry.

## Included

- Brand marks: ASAS and SMES N
- Header controls: unread bell and settings
- Navigation: Segment Maturation, Portfolio Analysis, Business Plan Execution, Map, Audit Trail, and Calculator
- Controls: dropdown chevron, Add icon, assignee/person, active-tab indicator, and count-badge frame
- KPIs: rig inventory calendar, rig target flag, success-rate chart, OGIP flame, and active-leads progress ring
- Stage headers: Lead Assessment, Risk Analysis, Pre-Well Delivery, Pre Drilling, Post Drilling, and Post Testing
- Status: completed, pending, and not started

Text, cards, separators, borders, and layout containers are not icons and are intentionally not traced. The progress percentage and stage-count numbers remain live UI text; their vector ring/frame is included.

## File organization

```text
icons/
  brand/
  navigation/
  kpi/
  stages/
  status/
  ui/
preview/
  contact-sheet.svg
  contact-sheet.png
  index.html
manifest.json
tokens.css
```

## Use

```html
<img src="icons/navigation/map-pin.svg" width="32" height="32" alt="Map">
```

Most outline assets use the screenshot-matched navy `#131C65`. Multi-color brand, notification, flame, progress, and status assets preserve their screenshot colors. To create a themed variant, replace the navy stroke value or target it after inlining the SVG.

```html
<svg class="dashboard-icon dashboard-icon--light" ...>
  <!-- copied icon geometry -->
</svg>
<style>.dashboard-icon--light [stroke="#131C65"]{stroke:#fff}</style>
```

For a labeled button or navigation item, mark the inline SVG `aria-hidden="true"`. For a standalone `<img>`, provide meaningful `alt` text. Each delivered file also contains a unique `<title>` for direct standalone viewing.

## Design notes

- These are manually reconstructed vectors from JPEG screenshots, not embedded raster images and not auto-traced JPEG noise.
- Standard icons use rounded caps and joins with a consistent navy monoline treatment.
- `segment-maturation.svg` uses a wide `48 × 24` viewBox because it combines the growth chart and oil derrick.
- `active-leads-progress-ring.svg` contains the 68% arc only; place dynamic percentage text above it in the application.
- `count-badge-frame.svg` contains the frame only; keep stage counts as live text.

SVG structure follows the [W3C SVG 2 specification](https://www.w3.org/TR/SVG2/) and standard web embedding practices described by [MDN](https://developer.mozilla.org/en-US/docs/Web/SVG).
